=================
 minesweeper game
=================


.. toctree::
   :maxdepth: 1

   cell
   minesweeper
   graphicalboard
   console_main


